package decorator.demo2_1;
public class Xiyangyang extends YangYang {
	

	
	@Override
	public void run() {
		System.out.println("ϲ�����ڱ���");
	}

}
