package decorator.demo2_1;

public abstract class YangYang {
	public abstract void run();
}
